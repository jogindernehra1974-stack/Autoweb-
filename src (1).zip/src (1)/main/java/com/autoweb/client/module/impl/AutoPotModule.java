package com.autoweb.client.module.impl;

import com.autoweb.client.module.AutowebModule;
import com.autoweb.client.module.BoolSetting;
import com.autoweb.client.module.DoubleSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;

@Environment(value=EnvType.CLIENT)
public class AutoPotModule extends AutowebModule {
    private final DoubleSetting healthThreshold = new DoubleSetting("Health Threshold (HP)", 16.0, 1.0, 40.0);
    private final DoubleSetting cooldownSetting = new DoubleSetting("Cooldown (ms)", 1000.0, 100.0, 10000.0);
    private final BoolSetting revertSlot = new BoolSetting("Revert Slot", true);
    private final BoolSetting revertLook = new BoolSetting("Revert Look Direction", true);
    private long lastPotionTime = 0L;

    public AutoPotModule() {
        super("Auto Pot", "Automatically throws a splash healing potion when health is low.");
        this.settings.add(this.healthThreshold);
        this.settings.add(this.cooldownSetting);
        this.settings.add(this.revertSlot);
        this.settings.add(this.revertLook);
    }

    @Override
    public void onTick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        ClientPlayerInteractionManager im = client.interactionManager;
        if (player == null || im == null) return;

        float health = player.getHealth();
        if (health >= (float)(double)(Double)this.healthThreshold.getValue()) return;

        long now = System.currentTimeMillis();
        if (now - this.lastPotionTime < ((Double)this.cooldownSetting.getValue()).longValue()) return;

        int potionSlot = findSplashHealingPotion(player);
        if (potionSlot == -1) return;

        int prevSlot = player.getInventory().selectedSlot;
        float prevYaw = player.getYaw();
        float prevPitch = player.getPitch();

        player.getInventory().selectedSlot = potionSlot;
        player.setPitch(90.0f);
        if (client.getNetworkHandler() != null) {
            client.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                prevYaw, 90.0f, player.isOnGround()
            ));
        }

        im.interactItem(player, Hand.MAIN_HAND);
        this.lastPotionTime = now;

        if ((Boolean)this.revertSlot.getValue()) {
            player.getInventory().selectedSlot = prevSlot;
        }
        if ((Boolean)this.revertLook.getValue()) {
            player.setYaw(prevYaw);
            player.setPitch(prevPitch);
            if (client.getNetworkHandler() != null) {
                client.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                    prevYaw, prevPitch, player.isOnGround()
                ));
            }
        }
    }

    private static int findSplashHealingPotion(ClientPlayerEntity player) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (stack.isEmpty() || stack.getItem() != Items.SPLASH_POTION) continue;
            PotionContentsComponent contents = stack.get(DataComponentTypes.POTION_CONTENTS);
            if (contents == null) continue;
            for (StatusEffectInstance effect : contents.getEffects()) {
                if (effect.getEffectType().equals(StatusEffects.INSTANT_HEALTH)) {
                    return i;
                }
            }
        }
        return -1;
    }
}
