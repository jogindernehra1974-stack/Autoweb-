package com.autoweb.client.module.impl;

import com.autoweb.client.config.ConfigManager;
import com.autoweb.client.module.AutowebModule;
import com.autoweb.client.module.BoolSetting;
import com.autoweb.client.module.DoubleSetting;
import com.autoweb.client.module.EnumSetting;
import com.autoweb.client.util.BlockPlaceUtil;
import com.autoweb.client.util.TargetUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

@Environment(value=EnvType.CLIENT)
public class WallWebModule extends AutowebModule {
    private final DoubleSetting fovSetting = new DoubleSetting("FOV", 90.0, 0.0, 180.0);
    private final DoubleSetting rangeSetting = new DoubleSetting("Range", 5.0, 1.0, 10.0);
    private final DoubleSetting delaySetting = new DoubleSetting("Delay", 600.0, 50.0, 3000.0);
    private final EnumSetting prioritySetting = new EnumSetting("Priority", "nearest", "nearest", "lowest_health");
    private final BoolSetting revertSlot = new BoolSetting("Revert Slot", true);
    private long lastPlaceTime = 0L;
    private static final Direction[] HORIZONTALS = new Direction[]{
        Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST
    };

    public WallWebModule() {
        super("Wall Web", "Places webs on walls adjacent to a target's head.");
        this.settings.add(this.fovSetting);
        this.settings.add(this.rangeSetting);
        this.settings.add(this.delaySetting);
        this.settings.add(this.prioritySetting);
        this.settings.add(this.revertSlot);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;
        long now = System.currentTimeMillis();
        if (now - this.lastPlaceTime < ((Double)this.delaySetting.getValue()).longValue()) return;
        PlayerEntity target = TargetUtil.findTarget(client,
            (Double)this.fovSetting.getValue(),
            (Double)this.rangeSetting.getValue(),
            (String)this.prioritySetting.getValue(),
            ConfigManager.getFriendlist());
        if (target == null) return;
        ClientWorld world = client.world;
        int headY = (int)Math.floor(target.getY() + (double)target.getHeight());
        for (Direction dir : HORIZONTALS) {
            BlockPos wallPos = new BlockPos(
                (int)Math.floor(target.getX()) + dir.getOffsetX(),
                headY,
                (int)Math.floor(target.getZ()) + dir.getOffsetZ()
            );
            BlockState wallState = world.getBlockState(wallPos);
            if (!wallState.isSolidBlock(world, wallPos)) continue;
            Direction placeFace = dir.getOpposite();
            BlockPos webPos = wallPos.offset(placeFace);
            BlockState webState = world.getBlockState(webPos);
            if (!webState.isAir() && !webState.isReplaceable()) continue;
            if (BlockPlaceUtil.findCobwebInHotbar(client.player) == -1) break;
            boolean placed = BlockPlaceUtil.placeWebAt(webPos, client, (Double)this.rangeSetting.getValue(), (Boolean)this.revertSlot.getValue());
            if (!placed) continue;
            this.lastPlaceTime = now;
            return;
        }
    }
}
