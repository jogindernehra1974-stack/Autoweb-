package com.autoweb.client.module.impl;

import com.autoweb.client.module.AutowebModule;
import com.autoweb.client.module.DoubleSetting;
import com.autoweb.client.module.EnumSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

@Environment(value=EnvType.CLIENT)
public class JumpResetModule extends AutowebModule {
    private static final double KNOCKBACK_THRESHOLD = 0.15;
    private static final double JUMP_VELOCITY = 0.42;

    private final DoubleSetting delaySetting = new DoubleSetting("Trigger Delay (ms)", 0.0, 0.0, 500.0);
    private final EnumSetting resetModeSetting = new EnumSetting("Reset Mode", "full_reset", "full_reset", "vertical_only");

    private double prevVelX = 0.0;
    private double prevVelZ = 0.0;
    private long knockbackDetectedTime = -1L;

    public JumpResetModule() {
        super("Jump Reset", "Jumps when knockback is detected to cancel velocity.");
        this.settings.add(this.delaySetting);
        this.settings.add(this.resetModeSetting);
    }

    @Override
    protected void onEnabledChanged(boolean enabled) {
        if (!enabled) {
            this.knockbackDetectedTime = -1L;
        }
    }

    @Override
    public void onTick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null) return;

        Vec3d vel = player.getVelocity();
        long now = System.currentTimeMillis();

        double dVelX = vel.x - this.prevVelX;
        double dVelZ = vel.z - this.prevVelZ;
        double horizDelta = Math.sqrt(dVelX * dVelX + dVelZ * dVelZ);

        if (horizDelta > KNOCKBACK_THRESHOLD && this.knockbackDetectedTime == -1L) {
            this.knockbackDetectedTime = now;
        }

        if (this.knockbackDetectedTime != -1L
                && now - this.knockbackDetectedTime >= ((Double) this.delaySetting.getValue()).longValue()) {
            this.fireJump(player);
            this.knockbackDetectedTime = -1L;
        }

        this.prevVelX = vel.x;
        this.prevVelZ = vel.z;
    }

    private void fireJump(ClientPlayerEntity player) {
        Vec3d cur = player.getVelocity();
        boolean fullReset = "full_reset".equals(this.resetModeSetting.getValue());
        if (fullReset) {
            player.setVelocity(0.0, JUMP_VELOCITY, 0.0);
        } else {
            player.setVelocity(cur.x, JUMP_VELOCITY, cur.z);
        }
    }
}
