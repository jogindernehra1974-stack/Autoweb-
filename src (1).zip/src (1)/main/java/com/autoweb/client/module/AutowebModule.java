package com.autoweb.client.module;

import com.autoweb.client.config.ConfigManager;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

@Environment(value=EnvType.CLIENT)
public abstract class AutowebModule {
    private final String name;
    private final String description;
    private boolean enabled = false;
    private KeyBinding keyBinding;
    private int boundKeyCode = -1;
    private boolean keyWasDown = false;
    protected final List<Setting<?>> settings = new ArrayList<>();

    protected AutowebModule(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public void registerKeyBinding() {
        this.keyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.autoweb." + this.name.toLowerCase().replace(' ', '_'),
            InputUtil.Type.KEYSYM,
            -1,
            "key.categories.gameplay"
        ));
    }

    public void tickModule(MinecraftClient client) {
        if (this.boundKeyCode != -1 && client.getWindow() != null) {
            boolean isDown = GLFW.glfwGetKey(client.getWindow().getHandle(), this.boundKeyCode) == 1;
            if (isDown && !this.keyWasDown) {
                this.onKeyPress(client);
            }
            this.keyWasDown = isDown;
        }
        if (this.enabled) {
            this.onTick(client);
        }
    }

    public void onKeyPress(MinecraftClient client) {
        this.toggle();
    }

    public void toggle() {
        this.setEnabled(!this.enabled);
    }

    public void setEnabled(boolean enabled) {
        boolean wasEnabled = this.enabled;
        this.enabled = enabled;
        if (wasEnabled != enabled) {
            this.onEnabledChanged(enabled);
            ConfigManager.save();
        }
    }

    protected void onEnabledChanged(boolean enabled) {}

    public void onTick(MinecraftClient client) {}

    public void setKeyCode(int keyCode) {
        this.boundKeyCode = keyCode;
        if (this.keyBinding != null) {
            InputUtil.Key key = keyCode == -1 ? InputUtil.UNKNOWN_KEY : InputUtil.Type.KEYSYM.createFromCode(keyCode);
            this.keyBinding.setBoundKey(key);
            KeyBinding.updateKeysByCode();
        }
        ConfigManager.save();
    }

    public int getBoundKeyCode() {
        return this.boundKeyCode;
    }

    public static String keyName(int keyCode) {
        if (keyCode == -1 || keyCode <= 0) return "NONE";
        String n = GLFW.glfwGetKeyName(keyCode, 0);
        if (n != null && !n.isBlank()) return n.toUpperCase();
        return switch (keyCode) {
            case 32 -> "SPACE";
            case 340 -> "L-SHIFT";
            case 344 -> "R-SHIFT";
            case 341 -> "L-CTRL";
            case 345 -> "R-CTRL";
            case 342 -> "L-ALT";
            case 346 -> "R-ALT";
            case 258 -> "TAB";
            case 280 -> "CAPS";
            case 257 -> "ENTER";
            case 259 -> "BKSP";
            case 261 -> "DEL";
            case 260 -> "INS";
            case 268 -> "HOME";
            case 269 -> "END";
            case 266 -> "PGUP";
            case 267 -> "PGDN";
            case 265 -> "UP";
            case 264 -> "DOWN";
            case 263 -> "LEFT";
            case 262 -> "RIGHT";
            default -> "KEY_" + keyCode;
        };
    }

    public String getName() { return this.name; }
    public String getDescription() { return this.description; }
    public boolean isEnabled() { return this.enabled; }
    public KeyBinding getKeyBinding() { return this.keyBinding; }
    public List<Setting<?>> getSettings() { return this.settings; }
}
