package com.autoweb.client.module;

public class BoolSetting extends Setting<Boolean> {
    public BoolSetting(String name, boolean value) {
        super(name, value);
    }

    public void toggle() {
        this.value = !(Boolean)this.value;
    }
}
