package com.autoweb.client.module;

import com.autoweb.client.config.ConfigManager;
import com.autoweb.client.gui.AutoWebScreen;
import com.autoweb.client.module.impl.AutoLavaModule;
import com.autoweb.client.module.impl.AutoPotModule;
import com.autoweb.client.module.impl.AutoWebAttackModule;
import com.autoweb.client.module.impl.FriendlistModule;
import com.autoweb.client.module.impl.JumpResetModule;
import com.autoweb.client.module.impl.PressableWebAttackModule;
import com.autoweb.client.module.impl.StunWebModule;
import com.autoweb.client.module.impl.WallWebModule;
import com.autoweb.client.module.impl.WebBubbleModule;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

@Environment(value=EnvType.CLIENT)
public final class ModuleManager {
    private static final List<AutowebModule> modules = new ArrayList<>();
    private static KeyBinding guiKey;

    private ModuleManager() {}

    public static void init() {
        register(new AutoWebAttackModule());
        register(new PressableWebAttackModule());
        register(new WebBubbleModule());
        register(new StunWebModule());
        register(new WallWebModule());
        register(new FriendlistModule());
        register(new AutoLavaModule());
        register(new JumpResetModule());
        register(new AutoPotModule());
        guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.autoweb.gui",
            InputUtil.Type.KEYSYM,
            79,
            "key.categories.gameplay"
        ));
        ConfigManager.registerModules(modules);
        ConfigManager.applyPendingModuleConfig();
        for (AutowebModule m : modules) {
            m.registerKeyBinding();
        }
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (guiKey.wasPressed()) {
                if (client.currentScreen != null) continue;
                client.setScreen(new AutoWebScreen());
            }
            for (AutowebModule m : modules) {
                m.tickModule(client);
            }
        });
    }

    private static void register(AutowebModule m) {
        modules.add(m);
    }

    public static List<AutowebModule> getModules() {
        return Collections.unmodifiableList(modules);
    }
}
