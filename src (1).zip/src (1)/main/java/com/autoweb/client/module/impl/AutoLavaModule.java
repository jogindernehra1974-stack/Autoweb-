package com.autoweb.client.module.impl;

import com.autoweb.client.config.ConfigManager;
import com.autoweb.client.module.AutowebModule;
import com.autoweb.client.module.BoolSetting;
import com.autoweb.client.module.DoubleSetting;
import com.autoweb.client.module.EnumSetting;
import com.autoweb.client.util.BlockPlaceUtil;
import com.autoweb.client.util.TargetUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;

@Environment(value=EnvType.CLIENT)
public class AutoLavaModule extends AutowebModule {
    private static final int PHASE_IDLE = 0;
    private static final int PHASE_PLACING = 1;
    private static final int PHASE_PICKING_UP = 2;

    private final DoubleSetting fovSetting = new DoubleSetting("FOV", 90.0, 0.0, 180.0);
    private final DoubleSetting rangeSetting = new DoubleSetting("Range", 5.0, 1.0, 10.0);
    private final DoubleSetting delaySetting = new DoubleSetting("Delay (ms)", 800.0, 200.0, 5000.0);
    private final DoubleSetting pickupDelaySetting = new DoubleSetting("Pickup Delay (ms)", 150.0, 50.0, 1000.0);
    private final EnumSetting prioritySetting = new EnumSetting("Priority", "nearest", "nearest", "lowest_health");
    private final BoolSetting revertSlot = new BoolSetting("Revert Slot", true);

    private int phase = PHASE_IDLE;
    private long lastActionTime = 0L;
    private long pickupTime = 0L;
    private BlockPos lavaPos = null;
    private int lavaBucketSlot = -1;
    private int savedSlot = -1;

    public AutoLavaModule() {
        super("Auto Lava", "Places lava at a target in cobweb, then picks it up.");
        this.settings.add(this.fovSetting);
        this.settings.add(this.rangeSetting);
        this.settings.add(this.delaySetting);
        this.settings.add(this.pickupDelaySetting);
        this.settings.add(this.prioritySetting);
        this.settings.add(this.revertSlot);
    }

    @Override
    protected void onEnabledChanged(boolean enabled) {
        if (!enabled) {
            this.phase = PHASE_IDLE;
            this.lavaPos = null;
        }
    }

    @Override
    public void onTick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        ClientWorld world = client.world;
        ClientPlayerInteractionManager im = client.interactionManager;
        if (player == null || world == null || im == null) return;

        long now = System.currentTimeMillis();

        if (phase == PHASE_IDLE) {
            if (now - lastActionTime < ((Double)this.delaySetting.getValue()).longValue()) return;
            lavaBucketSlot = BlockPlaceUtil.findLavaBucketInHotbar(player);
            if (lavaBucketSlot == -1) return;
            PlayerEntity target = TargetUtil.findTarget(client,
                (Double)this.fovSetting.getValue(),
                (Double)this.rangeSetting.getValue(),
                (String)this.prioritySetting.getValue(),
                ConfigManager.getFriendlist());
            if (target == null) return;
            BlockPos targetFeet = BlockPos.ofFloored(target.getX(), target.getY(), target.getZ());
            if (world.getBlockState(targetFeet).getBlock() != Blocks.COBWEB) return;
            savedSlot = player.getInventory().selectedSlot;
            player.getInventory().selectedSlot = lavaBucketSlot;
            lavaPos = targetFeet;
            forceLookAt(player, client,
                lavaPos.getX() + 0.5,
                lavaPos.getY() + 0.5,
                lavaPos.getZ() + 0.5);
            im.interactItem(player, Hand.MAIN_HAND);
            phase = PHASE_PLACING;
            pickupTime = now + ((Double)this.pickupDelaySetting.getValue()).longValue();
        } else if (phase == PHASE_PLACING) {
            if (now < pickupTime) return;
            if (lavaPos == null) {
                phase = PHASE_IDLE;
                return;
            }
            if (world.getBlockState(lavaPos).getBlock() != Blocks.LAVA) {
                phase = PHASE_IDLE;
                lastActionTime = now;
                if ((Boolean)this.revertSlot.getValue() && savedSlot != -1) {
                    player.getInventory().selectedSlot = savedSlot;
                }
                return;
            }
            forceLookAt(player, client,
                lavaPos.getX() + 0.5,
                lavaPos.getY() + 0.5,
                lavaPos.getZ() + 0.5);
            im.interactItem(player, Hand.MAIN_HAND);
            phase = PHASE_PICKING_UP;
            lastActionTime = now;
        } else if (phase == PHASE_PICKING_UP) {
            if ((Boolean)this.revertSlot.getValue() && savedSlot != -1) {
                player.getInventory().selectedSlot = savedSlot;
            }
            phase = PHASE_IDLE;
            lavaPos = null;
        }
    }

    private void forceLookAt(ClientPlayerEntity player, MinecraftClient client, double tx, double ty, double tz) {
        double eyeX = player.getEyePos().x;
        double eyeY = player.getEyePos().y;
        double eyeZ = player.getEyePos().z;
        double dx = tx - eyeX;
        double dy = ty - eyeY;
        double dz = tz - eyeZ;
        double horizDist = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
        float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horizDist)));
        player.setYaw(yaw);
        player.setPitch(pitch);
        if (client.getNetworkHandler() != null) {
            client.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                yaw, pitch, player.isOnGround()
            ));
        }
    }
}
