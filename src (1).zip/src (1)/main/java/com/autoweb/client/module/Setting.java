package com.autoweb.client.module;

public abstract class Setting<T> {
    protected final String name;
    protected T value;

    protected Setting(String name, T value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return this.name;
    }

    public T getValue() {
        return this.value;
    }

    public void setValue(T v) {
        this.value = v;
    }
}
