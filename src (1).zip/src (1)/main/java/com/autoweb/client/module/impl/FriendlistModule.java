package com.autoweb.client.module.impl;

import com.autoweb.client.config.ConfigManager;
import com.autoweb.client.module.AutowebModule;
import com.autoweb.client.util.TargetUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;

@Environment(value=EnvType.CLIENT)
public class FriendlistModule extends AutowebModule {
    public FriendlistModule() {
        super("Friendlist", "Keybind adds the looked-at player to your friend list.");
    }

    @Override
    public void onKeyPress(MinecraftClient client) {
        PlayerEntity target = TargetUtil.getLookedAtPlayer(client, 10.0);
        if (target != null) {
            String name = target.getName().getString();
            boolean added = ConfigManager.addFriend(name);
            if (client.player != null) {
                client.player.sendMessage(
                    Text.literal(added
                        ? "[AutoWeb] Added " + name + " to friendlist."
                        : "[AutoWeb] " + name + " is already in friendlist."),
                    true
                );
            }
        }
    }

    @Override
    public void onTick(MinecraftClient client) {}

    @Override
    public boolean isEnabled() {
        return true;
    }
}
