package com.autoweb.client.module;

public class EnumSetting extends Setting<String> {
    private final String[] options;

    public EnumSetting(String name, String defaultValue, String... options) {
        super(name, defaultValue);
        this.options = options;
    }

    public String[] getOptions() { return this.options; }

    public void cycleNext() {
        for (int i = 0; i < this.options.length; ++i) {
            if (!this.options[i].equals(this.value)) continue;
            this.value = this.options[(i + 1) % this.options.length];
            return;
        }
        if (this.options.length > 0) {
            this.value = this.options[0];
        }
    }
}
