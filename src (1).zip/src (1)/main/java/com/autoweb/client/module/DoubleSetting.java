package com.autoweb.client.module;

public class DoubleSetting extends Setting<Double> {
    private final double min;
    private final double max;

    public DoubleSetting(String name, double value, double min, double max) {
        super(name, value);
        this.min = min;
        this.max = max;
    }

    public double getMin() { return this.min; }
    public double getMax() { return this.max; }

    public void setClampedValue(double v) {
        this.value = Math.max(this.min, Math.min(this.max, v));
    }

    public double getSliderFraction() {
        return ((Double)this.value - this.min) / (this.max - this.min);
    }

    public void setFromFraction(double fraction) {
        this.setClampedValue(this.min + fraction * (this.max - this.min));
    }
}
