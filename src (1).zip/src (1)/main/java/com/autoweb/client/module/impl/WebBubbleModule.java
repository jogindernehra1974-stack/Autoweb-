package com.autoweb.client.module.impl;

import com.autoweb.client.module.AutowebModule;
import com.autoweb.client.module.BoolSetting;
import com.autoweb.client.module.DoubleSetting;
import com.autoweb.client.util.BlockPlaceUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;

@Environment(value=EnvType.CLIENT)
public class WebBubbleModule extends AutowebModule {
    private final DoubleSetting delayBetween = new DoubleSetting("Place Delay (ms)", 60.0, 20.0, 500.0);
    private final BoolSetting continuous = new BoolSetting("Continuous", false);
    private final BoolSetting revertSlot = new BoolSetting("Revert Slot", true);
    private final List<int[]> pendingPlacements = new ArrayList<>();
    private long nextPlaceTime = 0L;
    private boolean running = false;

    private static final int[][] OFFSETS = new int[][]{{0, -1, 0}, {0, -2, 0}, {0, -3, 0}};

    public WebBubbleModule() {
        super("Web Bubble", "Places 3 cobwebs directly beneath you, looking down.");
        this.settings.add(this.delayBetween);
        this.settings.add(this.continuous);
        this.settings.add(this.revertSlot);
    }

    @Override
    protected void onEnabledChanged(boolean enabled) {
        if (enabled) {
            this.startBubble();
        } else {
            this.pendingPlacements.clear();
            this.running = false;
        }
    }

    private void startBubble() {
        this.pendingPlacements.clear();
        for (int[] off : OFFSETS) {
            this.pendingPlacements.add(off);
        }
        this.nextPlaceTime = System.currentTimeMillis();
        this.running = true;
    }

    @Override
    public void onTick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null) return;
        if (!this.running) return;
        long now = System.currentTimeMillis();
        if (now < this.nextPlaceTime) return;
        if (this.pendingPlacements.isEmpty()) {
            if ((Boolean)this.continuous.getValue()) {
                this.startBubble();
            } else {
                this.setEnabled(false);
            }
            return;
        }
        this.forceLookDown(player, client);
        if (BlockPlaceUtil.findCobwebInHotbar(player) == -1) {
            this.setEnabled(false);
            return;
        }
        int[] off = this.pendingPlacements.remove(0);
        BlockPos pos = BlockPos.ofFloored(
            player.getX() + off[0],
            player.getY() + off[1],
            player.getZ() + off[2]
        );
        BlockPlaceUtil.placeWebAt(pos, client, 4.5, (Boolean)this.revertSlot.getValue());
        this.nextPlaceTime = now + ((Double)this.delayBetween.getValue()).longValue();
    }

    private void forceLookDown(ClientPlayerEntity player, MinecraftClient client) {
        player.setPitch(90.0f);
        if (client.getNetworkHandler() != null) {
            client.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                player.getYaw(), 90.0f, player.isOnGround()
            ));
        }
    }
}
