package com.autoweb.client.module.impl;

import com.autoweb.client.config.ConfigManager;
import com.autoweb.client.module.AutowebModule;
import com.autoweb.client.module.BoolSetting;
import com.autoweb.client.module.DoubleSetting;
import com.autoweb.client.module.EnumSetting;
import com.autoweb.client.util.BlockPlaceUtil;
import com.autoweb.client.util.TargetUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;

@Environment(value=EnvType.CLIENT)
public class PressableWebAttackModule extends AutowebModule {
    private static final long REARM_COOLDOWN_MS = 400L;
    private final DoubleSetting fovSetting = new DoubleSetting("FOV", 90.0, 0.0, 180.0);
    private final DoubleSetting rangeSetting = new DoubleSetting("Range", 5.0, 1.0, 10.0);
    private final EnumSetting prioritySetting = new EnumSetting("Priority", "nearest", "nearest", "lowest_health");
    private final BoolSetting revertSlot = new BoolSetting("Revert Slot", true);
    private long lastFireTime = 0L;
    private boolean pendingFire = false;

    public PressableWebAttackModule() {
        super("Pressable Web Attack", "Places one cobweb on key press, then disarms.");
        this.settings.add(this.fovSetting);
        this.settings.add(this.rangeSetting);
        this.settings.add(this.prioritySetting);
        this.settings.add(this.revertSlot);
    }

    @Override
    public void onKeyPress(MinecraftClient client) {
        long now = System.currentTimeMillis();
        if (now - this.lastFireTime < 400L) return;
        this.pendingFire = true;
    }

    @Override
    public void onTick(MinecraftClient client) {}

    @Override
    public void tickModule(MinecraftClient client) {
        super.tickModule(client);
        if (!this.pendingFire) return;
        this.pendingFire = false;
        if (client.player == null || client.world == null) return;
        if (BlockPlaceUtil.findCobwebInHotbar(client.player) == -1) return;
        PlayerEntity target = TargetUtil.findTarget(client,
            (Double)this.fovSetting.getValue(),
            (Double)this.rangeSetting.getValue(),
            (String)this.prioritySetting.getValue(),
            ConfigManager.getFriendlist());
        if (target == null) return;
        BlockPos feetPos = BlockPos.ofFloored(target.getX(), target.getY(), target.getZ());
        BlockPlaceUtil.placeWebAt(feetPos, client, (Double)this.rangeSetting.getValue(), (Boolean)this.revertSlot.getValue());
        this.lastFireTime = System.currentTimeMillis();
    }

    @Override
    public boolean isEnabled() {
        return false;
    }
}
