package com.autoweb.client.module.impl;

import com.autoweb.client.module.AutowebModule;
import com.autoweb.client.module.BoolSetting;
import com.autoweb.client.module.DoubleSetting;
import com.autoweb.client.util.BlockPlaceUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;

@Environment(value=EnvType.CLIENT)
public class StunWebModule extends AutowebModule {
    private final DoubleSetting cooldownSetting = new DoubleSetting("Re-trigger Cooldown (ms)", 2000.0, 500.0, 10000.0);
    private final BoolSetting revertSlot = new BoolSetting("Revert Slot", true);
    private boolean shieldWasCoolingDown = false;
    private long lastTriggerTime = 0L;

    public StunWebModule() {
        super("Stun Web", "Places a web at your feet when your shield breaks.");
        this.settings.add(this.cooldownSetting);
        this.settings.add(this.revertSlot);
    }

    @Override
    public void onTick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null) return;
        boolean shieldCoolingNow = player.getItemCooldownManager().isCoolingDown(Items.SHIELD);
        long now = System.currentTimeMillis();
        if (shieldCoolingNow && !this.shieldWasCoolingDown && now - this.lastTriggerTime >= ((Double)this.cooldownSetting.getValue()).longValue()) {
            this.triggerStun(client, player);
            this.lastTriggerTime = now;
        }
        this.shieldWasCoolingDown = shieldCoolingNow;
    }

    private void triggerStun(MinecraftClient client, ClientPlayerEntity player) {
        if (BlockPlaceUtil.findCobwebInHotbar(player) == -1) return;
        BlockPos feetPos = BlockPos.ofFloored(player.getX(), player.getY(), player.getZ());
        BlockPlaceUtil.placeWebAt(feetPos, client, 4.5, (Boolean)this.revertSlot.getValue());
    }
}
