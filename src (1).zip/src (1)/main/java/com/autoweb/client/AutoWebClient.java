package com.autoweb.client;

import com.autoweb.client.config.ConfigManager;
import com.autoweb.client.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Environment(value=EnvType.CLIENT)
public class AutoWebClient implements ClientModInitializer {
    public static final String MOD_ID = "autoweb";
    public static final Logger LOGGER = LoggerFactory.getLogger("autoweb");

    @Override
    public void onInitializeClient() {
        LOGGER.info("AutoWeb initializing...");
        ConfigManager.load();
        ModuleManager.init();
        LOGGER.info("AutoWeb initialized with {} modules.", ModuleManager.getModules().size());
    }
}
