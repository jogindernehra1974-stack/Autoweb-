package com.autoweb.client.util;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

@Environment(value=EnvType.CLIENT)
public final class BlockPlaceUtil {
    private static final double REACH = 4.5;
    private static final Direction[] DIRECTIONS = new Direction[]{
        Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST, Direction.UP
    };

    private BlockPlaceUtil() {}

    public static boolean placeWebAt(BlockPos targetPos, MinecraftClient client, double maxReach) {
        return placeWebAt(targetPos, client, maxReach, true);
    }

    public static boolean placeWebAt(BlockPos targetPos, MinecraftClient client, double maxReach, boolean revertSlot) {
        ClientPlayerEntity player = client.player;
        ClientWorld world = client.world;
        ClientPlayerInteractionManager im = client.interactionManager;
        if (player == null || world == null || im == null) return false;
        double effectiveReach = Math.min(maxReach, 4.5);
        BlockState targetState = world.getBlockState(targetPos);
        if (!targetState.isAir() && !targetState.isReplaceable()) return false;
        BlockHitResult hit = findBackingFace(targetPos, world);
        if (hit == null) return false;
        double dist = player.getEyePos().distanceTo(hit.getPos());
        if (dist > effectiveReach) return false;
        int cobwebSlot = findCobwebInHotbar(player);
        if (cobwebSlot == -1) return false;
        int prevSlot = player.getInventory().selectedSlot;
        player.getInventory().selectedSlot = cobwebSlot;
        ActionResult result = im.interactBlock(player, Hand.MAIN_HAND, hit);
        if (revertSlot) {
            player.getInventory().selectedSlot = prevSlot;
        }
        return result.isAccepted();
    }

    private static BlockHitResult findBackingFace(BlockPos pos, ClientWorld world) {
        for (Direction dir : DIRECTIONS) {
            BlockPos adjPos = pos.offset(dir);
            BlockState adjState = world.getBlockState(adjPos);
            if (!adjState.isSolidBlock(world, adjPos)) continue;
            Direction face = dir.getOpposite();
            Vec3d hitVec = Vec3d.ofCenter(adjPos).add(
                face.getOffsetX() * 0.5,
                face.getOffsetY() * 0.5,
                face.getOffsetZ() * 0.5
            );
            return new BlockHitResult(hitVec, face, adjPos, false);
        }
        return null;
    }

    public static int findCobwebInHotbar(ClientPlayerEntity player) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (!stack.isEmpty() && stack.getItem() == Items.COBWEB) return i;
        }
        return -1;
    }

    public static int findLavaBucketInHotbar(ClientPlayerEntity player) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (!stack.isEmpty() && stack.getItem() == Items.LAVA_BUCKET) return i;
        }
        return -1;
    }

    public static boolean autoSwapCobwebToHotbar(ClientPlayerEntity player) {
        if (findCobwebInHotbar(player) != -1) return true;
        for (int i = 9; i < 36; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (stack.isEmpty() || stack.getItem() != Items.COBWEB) continue;
            int hotbarSlot = player.getInventory().selectedSlot;
            ItemStack prev = player.getInventory().getStack(hotbarSlot).copy();
            player.getInventory().setStack(hotbarSlot, stack.copy());
            player.getInventory().setStack(i, prev);
            return true;
        }
        return false;
    }

    public static boolean hasCobweb(ClientPlayerEntity player) {
        for (int i = 0; i < 36; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (!stack.isEmpty() && stack.getItem() == Items.COBWEB) return true;
        }
        return false;
    }
}
