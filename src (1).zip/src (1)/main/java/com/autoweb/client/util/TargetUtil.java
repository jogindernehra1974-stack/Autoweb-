package com.autoweb.client.util;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

@Environment(value=EnvType.CLIENT)
public final class TargetUtil {
    private TargetUtil() {}

    public static PlayerEntity findTarget(MinecraftClient client, double fovDegrees, double range, String priority, List<String> friendNames) {
        if (client.player == null || client.world == null) return null;
        ClientPlayerEntity self = client.player;
        ArrayList<PlayerEntity> candidates = new ArrayList<>();
        for (PlayerEntity p : client.world.getPlayers()) {
            if (p == self) continue;
            if (p.isSpectator()) continue;
            if (p.getHealth() <= 0.0f) continue;
            if (isFriend(p, friendNames)) continue;
            if (!isInRange(p, self, range)) continue;
            if (!isInFov(p, self, fovDegrees)) continue;
            candidates.add(p);
        }
        if (candidates.isEmpty()) return null;
        return switch (priority) {
            case "lowest_health" -> candidates.stream().min(Comparator.comparingDouble(LivingEntity::getHealth)).orElse(null);
            default -> candidates.stream().min(Comparator.comparingDouble(p -> p.squaredDistanceTo(self))).orElse(null);
        };
    }

    private static boolean isInRange(PlayerEntity target, ClientPlayerEntity self, double range) {
        return target.squaredDistanceTo(self) <= range * range;
    }

    private static boolean isInFov(PlayerEntity target, ClientPlayerEntity self, double fovDegrees) {
        Vec3d look = self.getRotationVec(1.0f).normalize();
        Vec3d targetPos = new Vec3d(
            target.getX(),
            target.getY() + (double)target.getHeight() * 0.5,
            target.getZ()
        );
        Vec3d toTarget = targetPos.subtract(self.getEyePos()).normalize();
        double dot = Math.max(-1.0, Math.min(1.0, look.dotProduct(toTarget)));
        double angleDeg = Math.toDegrees(Math.acos(dot));
        return angleDeg <= fovDegrees / 2.0;
    }

    public static boolean isFriend(PlayerEntity player, List<String> friendNames) {
        if (friendNames == null || friendNames.isEmpty()) return false;
        String name = player.getName().getString().toLowerCase();
        String uuid = player.getUuidAsString();
        return friendNames.contains(name) || friendNames.contains(uuid.toLowerCase());
    }

    public static PlayerEntity getLookedAtPlayer(MinecraftClient client, double range) {
        if (client.player == null || client.world == null) return null;
        Entity targeted = client.targetedEntity;
        if (targeted instanceof PlayerEntity p && p.squaredDistanceTo(client.player) <= range * range) {
            return p;
        }
        return null;
    }
}
