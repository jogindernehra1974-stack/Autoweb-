package com.autoweb.client.config;

import com.autoweb.client.AutoWebClient;
import com.autoweb.client.module.AutowebModule;
import com.autoweb.client.module.BoolSetting;
import com.autoweb.client.module.DoubleSetting;
import com.autoweb.client.module.EnumSetting;
import com.autoweb.client.module.Setting;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.fabricmc.loader.api.FabricLoader;

public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance().getConfigDir().resolve("autoweb.json");
    private static final List<String> friendlist = new ArrayList<>();
    private static List<AutowebModule> modules = Collections.emptyList();
    private static JsonObject pendingModulesJson = null;

    private ConfigManager() {
    }

    public static void registerModules(List<AutowebModule> mods) {
        modules = mods;
    }

    public static List<String> getFriendlist() {
        return friendlist;
    }

    public static void save() {
        try {
            JsonObject root = new JsonObject();
            JsonObject modulesObj = new JsonObject();
            for (AutowebModule m : modules) {
                JsonObject mObj = new JsonObject();
                mObj.addProperty("enabled", m.isEnabled());
                mObj.addProperty("keyCode", m.getBoundKeyCode());
                JsonObject settingsObj = new JsonObject();
                for (Setting<?> s : m.getSettings()) {
                    if (s instanceof DoubleSetting ds) {
                        settingsObj.addProperty(ds.getName(), (Number)ds.getValue());
                    } else if (s instanceof BoolSetting bs) {
                        settingsObj.addProperty(bs.getName(), (Boolean)bs.getValue());
                    } else if (s instanceof EnumSetting es) {
                        settingsObj.addProperty(es.getName(), (String)es.getValue());
                    }
                }
                mObj.add("settings", (JsonElement)settingsObj);
                modulesObj.add(m.getName(), (JsonElement)mObj);
            }
            root.add("modules", (JsonElement)modulesObj);
            JsonArray friendsArr = new JsonArray();
            friendlist.forEach(friendsArr::add);
            root.add("friendlist", (JsonElement)friendsArr);
            Files.createDirectories(CONFIG_PATH.getParent());
            try (OutputStreamWriter w = new OutputStreamWriter(Files.newOutputStream(CONFIG_PATH), StandardCharsets.UTF_8)) {
                GSON.toJson((JsonElement)root, (Appendable)w);
            }
        } catch (IOException e) {
            AutoWebClient.LOGGER.error("Failed to save config", (Throwable)e);
        }
    }

    public static void load() {
        if (!Files.exists(CONFIG_PATH, new LinkOption[0])) return;
        try (InputStreamReader r = new InputStreamReader(Files.newInputStream(CONFIG_PATH), StandardCharsets.UTF_8)) {
            JsonObject root = GSON.fromJson((Reader)r, JsonObject.class);
            if (root == null) return;
            if (root.has("friendlist") && root.get("friendlist").isJsonArray()) {
                friendlist.clear();
                root.getAsJsonArray("friendlist").forEach(el -> friendlist.add(el.getAsString().toLowerCase()));
            }
            pendingModulesJson = root.has("modules") ? root.getAsJsonObject("modules") : null;
        } catch (Exception e) {
            AutoWebClient.LOGGER.error("Failed to load config", (Throwable)e);
        }
    }

    public static void applyPendingModuleConfig() {
        if (pendingModulesJson == null) return;
        JsonObject obj = pendingModulesJson;
        pendingModulesJson = null;
        for (AutowebModule m : modules) {
            if (!obj.has(m.getName())) continue;
            JsonObject mObj = obj.getAsJsonObject(m.getName());
            if (mObj.has("enabled")) m.setEnabled(mObj.get("enabled").getAsBoolean());
            if (mObj.has("keyCode")) m.setKeyCode(mObj.get("keyCode").getAsInt());
            if (!mObj.has("settings")) continue;
            JsonObject sObj = mObj.getAsJsonObject("settings");
            for (Setting<?> s : m.getSettings()) {
                if (!sObj.has(s.getName())) continue;
                try {
                    if (s instanceof DoubleSetting ds) {
                        ds.setClampedValue(sObj.get(s.getName()).getAsDouble());
                    } else if (s instanceof BoolSetting bs) {
                        bs.setValue(sObj.get(s.getName()).getAsBoolean());
                    } else if (s instanceof EnumSetting es) {
                        es.setValue(sObj.get(s.getName()).getAsString());
                    }
                } catch (Exception ignored) {}
            }
        }
    }

    public static boolean addFriend(String nameOrUuid) {
        String key = nameOrUuid.toLowerCase().trim();
        if (key.isEmpty() || friendlist.contains(key)) return false;
        friendlist.add(key);
        ConfigManager.save();
        return true;
    }

    public static boolean removeFriend(String nameOrUuid) {
        boolean removed = friendlist.remove(nameOrUuid.toLowerCase().trim());
        if (removed) ConfigManager.save();
        return removed;
    }
}
